<!-- Chatbot Component Start -->
<style>
  #chatbot-toggle {
    position: fixed;
    bottom: 25px;
    right: 25px;
    background-color: #4CAF50;
    color: white;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    font-size: 30px;
    border: none;
    cursor: pointer;
    z-index: 999;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  #chat-container {
    position: fixed;
    bottom: 100px;
    right: 25px;
    width: 400px;
    background: white;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0,0,0,0.3);
    display: none;
    flex-direction: column;
    overflow: hidden;
    z-index: 998;
    font-family: Arial, sans-serif;
  }

  #chatbox {
    height: 400px;
    overflow-y: auto;
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }

  .message {
    max-width: 70%;
    padding: 10px 15px;
    border-radius: 15px;
    word-wrap: break-word;
  }

  .user {
    align-self: flex-end;
    background-color: #DCF8C6;
  }

  .bot {
    align-self: flex-start;
    background-color: #ECECEC;
  }

  .loader {
    align-self: flex-start;
    background-color: #ECECEC;
    padding: 10px 15px;
    border-radius: 15px;
    font-style: italic;
    opacity: 0.6;
  }

  #input-area {
    display: flex;
    border-top: 1px solid #ddd;
  }

  #user-input {
    flex-grow: 1;
    border: none;
    padding: 15px;
    font-size: 16px;
    outline: none;
  }

  #send-btn {
    background: #4CAF50;
    color: white;
    border: none;
    padding: 15px;
    cursor: pointer;
    font-size: 16px;
  }

  #send-btn:hover {
    background: #45a049;
  }
</style>

<!-- Toggle Button -->
<button id="chatbot-toggle" onclick="toggleChat()">💬</button>

<!-- Chat Container -->
<div id="chat-container">
  <div id="chatbox"></div>
  <div id="input-area">
    <input type="text" id="user-input" placeholder="Nhập tin nhắn..." />
    <button id="send-btn" onclick="sendMessage()">Gửi</button>
  </div>
</div>

<script>
  const input = document.getElementById('user-input');
  const chatbox = document.getElementById('chatbox');
  const chatContainer = document.getElementById('chat-container');

  function toggleChat() {
    if (chatContainer.style.display === "none" || chatContainer.style.display === "") {
      chatContainer.style.display = "flex";
    } else {
      chatContainer.style.display = "none";
    }
  }

  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });

  async function sendMessage() {
    const message = input.value.trim();
    if (!message) return;

    appendMessage('user', message);
    input.value = '';

    const loader = document.createElement('div');
    loader.className = 'loader';
    loader.textContent = 'Đang gõ...';
    chatbox.appendChild(loader);
    scrollToBottom();

    try {
      const response = await fetch('http://localhost:5005/webhooks/rest/webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sender: 'user1', message: message })
      });

      const data = await response.json();
      chatbox.removeChild(loader);

      if (data.length === 0) {
        appendMessage('bot', 'Xin lỗi, tôi không hiểu.');
      }

      data.forEach(msg => {
        appendMessage('bot', msg.text);
      });

    } catch (error) {
      chatbox.removeChild(loader);
      appendMessage('bot', 'Lỗi khi kết nối đến chatbot.');
      console.error('Lỗi:', error);
    }

    scrollToBottom();
  }

  function appendMessage(sender, text) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${sender}`;
    msgDiv.textContent = text;
    chatbox.appendChild(msgDiv);
  }

  function scrollToBottom() {
    chatbox.scrollTop = chatbox.scrollHeight;
  }
</script>
<!-- Chatbot Component End -->
